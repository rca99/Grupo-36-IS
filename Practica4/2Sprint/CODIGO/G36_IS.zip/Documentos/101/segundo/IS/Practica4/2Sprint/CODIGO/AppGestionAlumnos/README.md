Copiar la carpeta en el escritorio y compilar. 

g++ menuprincipal.cc BD.cc Alumno.cc Profesor.cc Profesor.h Alumno.h BD.h consoleLinux.h