echo 

xdg-open  listaAlumnos/;
	
