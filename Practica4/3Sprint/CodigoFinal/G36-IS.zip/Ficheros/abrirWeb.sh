echo 

xdg-open  Instrucciones/;
	
